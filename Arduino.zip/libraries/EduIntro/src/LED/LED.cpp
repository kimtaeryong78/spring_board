#include "LED.h"
#include "EduIntro.h"

Led::Led(uint8_t _pin) : Output(_pin) {}
