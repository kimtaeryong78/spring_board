package jmp.spring.service;

public interface Smtx {
	public void addData(String value);
}
